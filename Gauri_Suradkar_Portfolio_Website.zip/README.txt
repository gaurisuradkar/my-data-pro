# Gauri Suradkar — Portfolio Website

## Publish with GitHub Pages

1. Sign in to GitHub as `gaurisuradkar`.
2. Create a **new public repository** named exactly `gaurisuradkar.github.io`.
3. Upload `index.html` from this folder to the repository root (not inside another folder).
4. Commit the file.
5. Open the repository's **Settings → Pages**.
6. Under Build and deployment, choose **Deploy from a branch**; select `main` and `/ (root)`, then Save.
7. Wait a few minutes and visit: https://gaurisuradkar.github.io

## Before sharing with recruiters
Edit `index.html` and replace:
- `YOUR_EMAIL@example.com` with your email address.
- `[College / University name]` and `[Expected graduation year]`.
- LinkedIn link with your profile URL.
- Add real GitHub repository links, screenshots, and exact project implementation details.
- Confirm that every listed skill and project detail accurately reflects your work.

Your GitHub password is never needed for this process. Do not share it.
